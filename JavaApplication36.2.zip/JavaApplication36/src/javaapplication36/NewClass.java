/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication36;

/**
 *
 * @author andilenzama
 */
// EstateAgent class
public class NewClass {
    // Fixed commission percentage (5%)
    private static final double COMMISSION_RATE = 0.05;

    // ...

    public double calculateCommission(double propertyPrice) {
        // Calculate commission based on a fixed percentage
        return propertyPrice * COMMISSION_RATE;
    }

   
}