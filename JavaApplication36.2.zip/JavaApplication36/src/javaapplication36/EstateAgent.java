/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication36;

import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;

/**
 *
 * @author andilenzama
 */
@SupportedSourceVersion(SourceVersion.RELEASE_19)
public class EstateAgent implements IEstateAgent {
    @Override
    public double CalculateCommission(String propertyPrice, String agentCommission) {
        double price = Double.parseDouble(propertyPrice);
        double commissionPercentage = Double.parseDouble(agentCommission);
        return price * (commissionPercentage / 100.0);
    }

    @Override
    public boolean ValidateData(Data dataToValidate) {
        // Implement validation logic here
        // Return true if data is valid, false otherwise
        // You can use dataToValidate.getLocation(), dataToValidate.getAgentName(), etc.
        // Remember to handle exceptions for parsing doubles
        return true;
    }

    double calculateCommission(double propertyPrice) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    double calculateCommission(double propertyPrice, double commissionPercentage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}

