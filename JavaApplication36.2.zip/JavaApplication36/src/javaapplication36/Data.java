/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication36;

/**
 *
 * @author andilenzama
 */
   public class Data {
    private String location;
    private String agentName;
    private String propertyPrice;
    private String commissionPercentage;

    public Data(String location, String agentName, String propertyPrice, String commissionPercentage) {
        this.location = location;
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
        this.commissionPercentage = commissionPercentage;
    }

    public String getLocation() {
        return location;
    }

    public String getAgentName() {
        return agentName;
    }

    public String getPropertyPrice() {
        return propertyPrice;
    }

    public String getCommissionPercentage() {
        return commissionPercentage;
    }
}
    

