/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication36;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author andilenzama
 */



public class EstateAgentApp extends JFrame {
    private JComboBox<String> locationComboBox;
    private JTextField agentNameTextField, propertyPriceTextField, commissionTextField;
    private JTextArea reportTextArea;

    public EstateAgentApp() {
        initializeUI();
    }

    private void initializeUI() {
        // Frame setup
        setTitle("Estate Agent Commission Calculator");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Components
        locationComboBox = new JComboBox<>(new String[]{"Cape Town", "Durban", "Pretoria"});
        agentNameTextField = new JTextField();
        propertyPriceTextField = new JTextField();
        commissionTextField = new JTextField();
        reportTextArea = new JTextArea();
        reportTextArea.setEditable(false);

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        JMenuItem processReportItem = new JMenuItem("Process Report");
        processReportItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processReport();
            }
        });

        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        JMenuItem saveReportItem = new JMenuItem("Save Report");
        saveReportItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveReportToFile();
            }
        });

        fileMenu.add(exitItem);
        toolsMenu.add(processReportItem);
        toolsMenu.add(clearItem);
        toolsMenu.add(saveReportItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Layout
        setLayout(new GridLayout(5, 2));

        // Adding components to the frame
        add(new JLabel("Agent Location:"));
        add(locationComboBox);
        add(new JLabel("Agent Name:"));
        add(agentNameTextField);
        add(new JLabel("Property Price:"));
        add(propertyPriceTextField);
        add(new JLabel("Commission Percentage:"));
        add(commissionTextField);
        add(new JLabel("Report:"));
        add(new JScrollPane(reportTextArea));
    }

    private void processReport() {
        // Get input values
        String location = (String) locationComboBox.getSelectedItem();
        String agentName = agentNameTextField.getText();
        String propertyPriceStr = propertyPriceTextField.getText();
        String commissionStr = commissionTextField.getText();

        // Validate data
        EstateAgent estateAgent = new EstateAgent();
        Data dataToValidate = new Data(location, agentName, propertyPriceStr, commissionStr);
        if (estateAgent.ValidateData(dataToValidate)) {
            // Calculate commission
            double commission = estateAgent.CalculateCommission(propertyPriceStr, commissionStr);

            // Display report
            reportTextArea.setText("Agent Location: " + location + "\n");
            reportTextArea.append("Agent Name: " + agentName + "\n");
            reportTextArea.append("Commission: $" + commission);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check the data.");
        }
    }

    private void clearFields() {
        agentNameTextField.setText("");
        propertyPriceTextField.setText("");
        commissionTextField.setText("");
        reportTextArea.setText("");
    }

    private void saveReportToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write(reportTextArea.getText());
            JOptionPane.showMessageDialog(this, "Report saved to report.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstateAgentApp app = new EstateAgentApp();
            app.setVisible(true);
        });
    }
}
