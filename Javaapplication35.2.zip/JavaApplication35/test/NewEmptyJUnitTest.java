/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author andilenzama
 */


public class EstateAgentTest {
    // Test case for CalculateTotalSales_ReturnsTotalSales
    @Test
    public void calculateTotalSales_ReturnsTotalSales() {
        double[][] propertySales = {{800000, 700000}, {1500000, 1200000}, {2000000, 1600000}};
        EstateAgent estateAgent = new EstateAgent("Joe Bloggs", propertySales);
        double expectedTotalSales = 800000 + 700000 + 1500000 + 1200000 + 2000000 + 1600000;

        assertEquals(expectedTotalSales, estateAgent.estateAgentSales());
    }

    // Test case for CalculateTotalCommission_ReturnsCommission
    @Test
    public void calculateTotalCommission_ReturnsCommission() {
        double[][] propertySales = {{800000, 700000}, {1500000, 1200000}, {2000000, 1600000}};
        EstateAgent estateAgent = new EstateAgent("Joe Bloggs", propertySales);
        double expectedCommission = (800000 + 700000 + 1500000 + 1200000 + 2000000 + 1600000) * 0.02;

        assertEquals(expectedCommission, estateAgent.estateAgentCommission());
    }

    // Test case for TopAgent_ReturnsTopPosition
    @Test
    public void topAgent_ReturnsTopPosition() {
        double[][] propertySalesJoe = {{800000, 700000}, {1500000, 1200000}, {2000000, 1600000}};
        double[][] propertySalesJane = {{700000, 600000}, {1200000, 1000000}, {1800000, 1400000}};
        EstateAgent joeAgent = new EstateAgent("Joe Bloggs", propertySalesJoe);
        EstateAgent janeAgent = new EstateAgent("Jane Doe", propertySalesJane);
        double[] totalSales = {joeAgent.estateAgentSales(), janeAgent.estateAgentSales()};

        assertEquals(0, joeAgent.topEstateAgent(totalSales));
    }
}
