/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author andilenzama
 */



public class EstateAgentTest {

    @Test
    public void calculateTotalSales_ReturnsTotalSales() {
        EstateAgent estateAgent = new EstateAgent();
        double[] propertySales = {800000, 700000};

        double totalSales = estateAgent.estateAgentSales(propertySales);

        assertEquals(1500000, totalSales, 0);
    }

    @Test
    public void calculateTotalCommission_ReturnsCommission() {
        EstateAgent estateAgent = new EstateAgent();
        double totalSales = 1500000;

        double commission = estateAgent.estateAgentCommission(totalSales);

        assertEquals(30000, commission, 0);
    }

    @Test
    public void topAgent_ReturnsTopPosition() {
        EstateAgent estateAgent = new EstateAgent();
        double[] totalSales = {1500000, 1200000, 1600000};

        int topAgentIndex = estateAgent.topEstateAgent(totalSales);

        assertEquals(2, topAgentIndex);
    }
}
