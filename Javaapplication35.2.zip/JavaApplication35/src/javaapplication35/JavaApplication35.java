/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication35;

/**
 *
 * @author andilenzama
 */
public class JavaApplication35 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double[][] propertySales = {
                {800000, 700000},
                {1500000, 1200000},
                {2000000, 1600000}
        };

        double[] totalSales = new double[propertySales.length];
        double[] totalCommission = new double[propertySales.length];

        EstateAgent estateAgent = new EstateAgent();

        for (int i = 0; i < propertySales.length; i++) {
            totalSales[i] = estateAgent.estateAgentSales(propertySales[i]);
            totalCommission[i] = estateAgent.estateAgentCommission(totalSales[i]);
        }

        // Display total property sales and commission for each estate agent
        for (int i = 0; i < propertySales.length; i++) {
            System.out.println("Estate Agent " + (i + 1));
            System.out.println("Total Property Sales: R " + totalSales[i]);
            System.out.println("Commission Earned: R " + totalCommission[i]);
            System.out.println();
        }

        // Display top-selling estate agent
        int topAgentIndex = estateAgent.topEstateAgent(totalSales);
        System.out.println("Top-Selling Estate Agent: Estate Agent " + (topAgentIndex + 1));
    }

}

      